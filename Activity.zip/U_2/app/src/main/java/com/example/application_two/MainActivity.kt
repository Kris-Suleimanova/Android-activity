package com.example.application_two


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBox
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Place

import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha


import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter

import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.application_two.ui.theme.Application_twoTheme

import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Devices
import android.util.Log

class MainActivity : ComponentActivity() {
    private val TAG = "Log"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Application_twoTheme {
                Surface(
                    color = Color(0xFF87CEFA),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Card()
                }
            }
        }
        Log.d(TAG, "create_log_Сообщение")
        finish()
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "start_log_Сообщение")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "resume_log_Сообщение")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "pause_log_Сообщение")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "stop_log_Сообщение")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "destroy_log_Сообщение")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "restart_log_Сообщение")
    }
}

@Composable
fun Card() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        val k= painterResource(R.drawable.android_logo)
        Image(
            painter = k,
            contentDescription = null,
            Modifier
                .fillMaxHeight(0.18f)
                .background(Color(0xFF000080))
                .alpha(0.8f),
            colorFilter = ColorFilter.tint(Color.White),
            alignment = Alignment.Center

            )
        Text(
            text = stringResource(R.string.name),
            textAlign = TextAlign.Center,
            fontSize = 30.sp,
            color = Color.Black,
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold,
            letterSpacing =2.sp,
            lineHeight = 40.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            softWrap = true
        )
        Text(
            text = stringResource(R.string.graphic_designer),
            fontSize = 30.sp,
            color = Color(0xFF00008B),
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Italic,
            letterSpacing =2.sp,
            lineHeight = 40.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            softWrap = true
        )
        Spacer(
            modifier = Modifier.padding(bottom = 30.dp)
        )
        classt(
            t = stringResource(R.string.phonenumber),
            i = Icons.Rounded.Phone
        )

        classt(
            t = stringResource(R.string.email),
            i = Icons.Rounded.Email
        )
        classt(
            t = stringResource(R.string.address),
            i = Icons.Rounded.Place
        )
        classt(
            t = stringResource(R.string.site),
            i = Icons.Rounded.AccountBox
        )
    }
}

@Composable
fun classt(
    t: String, i: ImageVector
) {
    Row(
        modifier = Modifier.padding(12.dp)
    ) {
        Icon(
            imageVector = i,
            contentDescription = null,
            tint = Color(0xFF00008B),
            modifier = Modifier.weight(0.2f)
        )
        Text(
            text = t,
            color = Color.Black,
            fontSize = 18.sp,
            modifier = Modifier.weight(1.7f),
            fontFamily = FontFamily.Serif,
            letterSpacing = 0.1.sp,
            lineHeight = 24.sp,
            overflow = TextOverflow.Ellipsis,
            softWrap = true,
            maxLines = 2,
            fontWeight = FontWeight.Bold


        )
    }
}

@Preview(showBackground = true, showSystemUi = true, device = Devices.PIXEL_4, backgroundColor = 0xFF000000)
@Composable
fun P() {
    Surface(
        modifier = Modifier.fillMaxSize(), color = Color(0xFF87CEFA),  tonalElevation  = 4.dp,
        shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, Color.Black)
    ) {
        Application_twoTheme {
           Card()
        }
    }
}